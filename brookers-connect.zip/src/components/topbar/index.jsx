import React from 'react'

const TopBar = () => {
    return (
        <div className='py-0 px-3'>
            <p className='text-white'>BrokersConnect</p>
        </div>
    )
}

export default TopBar