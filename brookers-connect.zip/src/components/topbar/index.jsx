import React from 'react'

const TopBar = () => {
    return (
        <div className='p-3'>
            <p className='text-white'>BrokersConnect</p>
        </div>
    )
}

export default TopBar