import React from 'react'

const Legend = () => {
    return (
        <div>
            Legend
        </div>
    )
}

export default Legend