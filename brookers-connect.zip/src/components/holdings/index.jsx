import React from 'react'

const Holdings = () => {
    return (
        <div className='text-right p-3 bg-[#1A1A1A]'>
            <p className='font-bold text-white'>
                Holdings
            </p>
        </div>
    )
}

export default Holdings