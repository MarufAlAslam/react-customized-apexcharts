import React from 'react'

const Holdings = () => {
    return (
        <div className='text-right px-3 py-1 bg-[#1A1A1A]'>
            <p className='font-semibold cursor-pointer text-sm text-white hover:font-bold'>
                Holdings
            </p>
        </div>
    )
}

export default Holdings